// affinity-scores.js
import { graph } from './affinity-graph.js';
export const score = build(graph);
function build(edges){
  const adj={};
  edges.forEach(([a,b])=>{
    (adj[a]??=[]).push(b); (adj[b]??=[]).push(a);
  });
  const out={};
  for(const root of Object.keys(adj)){
    const dist={[root]:0}, q=[root];
    while(q.length){
      const n=q.shift();
      for(const nb of adj[n]||[]){
        if(dist[nb]==null){dist[nb]=dist[n]+1; q.push(nb);}
      }
    }
    for(const [cat,d] of Object.entries(dist)){
      if(cat===root) continue;
      const pct=Math.round(30*Math.pow(0.6,d-1));
      out[root]??={}; out[root][cat]=pct;
    }
  }
  return out;
}