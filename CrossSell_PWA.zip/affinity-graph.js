// affinity-graph.js
export const graph = [
  ["Cutting Tools","Coolants/Lubricants"],
  ["Cutting Tools","Measurement Tools"],
  ["Measurement Tools","Setup Aids"],
  ["Setup Aids","Inspection Fixtures"],
  ["Coolants/Lubricants","Abrasives"],
  ["Coolants/Lubricants","Fasteners"],
  ["Fasteners","Hand Tools"],
  ["Hand Tools","Threadlockers"],
  ["Fasteners","Abrasives"],
  ["Abrasives","Power Tools"],
  ["Power Tools","Tool Accessories"],
  ["Tool Accessories","Welding Consumables"],
  ["Welding Consumables","Welding Gas"],
  ["Welding Gas","Gas Regulators"],
  ["Abrasives","PPE"],
  ["Power Tools","PPE"],
  ["PPE","Safety Signage"]
];